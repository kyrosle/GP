#include "include/game.h"

Game::Game(GLuint width, GLuint height)
  : Width(width), Height(height), State(GameState::ACTIVE) {}

Game::~Game() {}

bool Game::Init() {
  return false;
}

void Game::DoCollision() {

}

void Game::ProcessInput(float dt) {

}

void Game::Update(float dt) {

}

void Game::Render() {

}
