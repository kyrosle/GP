#include "include/AndroidOut.h"

AndroidOut androidOut("AO");
std::ostream aout(&androidOut);