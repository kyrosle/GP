#ifndef _RENDERER_H__
#define _RENDERER_H__

#include "../../../../../../../../../Android/Sdk/ndk/25.1.8937393/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/include/EGL/egl.h"
#include "../../../../../../../../../Android/Sdk/ndk/25.1.8937393/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/include/c++/v1/memory"

#include "Model.h"
#include "Shader.h"

struct android_app;

class Renderer {
public:
  typedef std::shared_ptr<Renderer> ptr;

  /*!
   * @param pApp the android_app this Renderer belongs to, needed to configure GL
   */
  inline Renderer(android_app *pApp) :
    m_app(pApp),
    m_display(EGL_NO_DISPLAY),
    m_surface(EGL_NO_SURFACE),
    m_context(EGL_NO_CONTEXT),
    m_width(0),
    m_height(0),
    m_shaderNeedsNewProjectionMatrix(true) {
    initRenderer();
  }

  virtual ~Renderer();

  /*!
   * Handles input from the android_app.
   *
   * Note: this will clear the input queue
   */
  void handleInput();

  /*!
   * Renders all the models in the renderer
   */
  void render();

private:
  /*!
   * Performs necessary OpenGL initialization. Customize this if you want to change your EGL
   * context or application-wide settings.
   */
  void initRenderer();

  /*!
   * @brief we have to check every frame to see if the framebuffer has changed in size. If it has,
   * update the viewport accordingly
   */
  void updateRenderArea();

  /*!
   * Creates the models for this sample. You'd likely load a scene configuration from a file or
   * use some other setup logic in your full game.
   */
  void createModels();

  android_app *m_app;
  EGLDisplay m_display;
  EGLSurface m_surface;
  EGLContext m_context;
  EGLint m_width;
  EGLint m_height;

  bool m_shaderNeedsNewProjectionMatrix;

  std::unique_ptr<Shader> m_shader;
  std::vector<Model> m_models;
};

#endif