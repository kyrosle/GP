#ifndef _UTILITY_H__
#define _UTILITY_H__

#include "../../../../../../../../../Android/Sdk/ndk/25.1.8937393/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/include/c++/v1/cassert"
#include <string>
#include <memory>

using FileRawData = std::vector<uint8_t>;
using FileRawDataPtr = std::shared_ptr<FileRawData>;

class Utility {
public:
  static bool checkAndLogGlError(bool alwaysLog = false);

  static inline void assertGlError() { assert(checkAndLogGlError()); }

  /**
   * Generates an orthographic projection matrix given the half height, aspect ratio, near, and far
   * planes
   *
   * @param outMatrix the matrix to write into
   * @param halfHeight half of the height of the screen
   * @param aspect the width of the screen divided by the height
   * @param near the distance of the near plane
   * @param far the distance of the far plane
   * @return the generated matrix, this will be the same as @a outMatrix so you can chain calls
   *     together if needed
   */
  static float *buildOrthographicMatrix(
    float *outMatrix,
    float halfHeight,
    float aspect,
    float near,
    float far);

  static float *buildIdentityMatrix(float *outMatrix);

  /*
   * Used for sdk <= 30
   */
  static FileRawDataPtr LoadFileContent(const std::string &path, int &fileSize);

};

#endif