#ifndef _ANDROID_OUT_H__
#define _ANDROID_OUT_H__

// include files from ndk toolchain
#include "../../../../../../../../../Android/Sdk/ndk/25.1.8937393/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/include/android/log.h"
#include "../../../../../../../../../Android/Sdk/ndk/25.1.8937393/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/include/c++/v1/sstream"

/*!
 * Use this to log strings out to logcat. Note that you should use std::endl to commit the line
 *
 * ex:
 *  aout << "Hello World" << std::endl;
 */
extern std::ostream aout;

/*!
 * Use this class to create an output stream that writes to logcat. By default, a global one is
 * defined as @a aout
 */
class AndroidOut : public std::stringbuf {
public:
  /*!
   * Creates a new output stream for logcat
   * @param kLogTag the log tag to output
   */
  inline AndroidOut(const char *kLogTag) : m_logTag(kLogTag) {}

protected:
  virtual int sync() override {
    __android_log_print(ANDROID_LOG_DEBUG, m_logTag, "%s", str().c_str());
    str("");
    return 0;
  }

private:
  const char *m_logTag;
};

#endif