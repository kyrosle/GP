#ifndef _TEXTURE_ASSERT_H__
#define _TEXTURE_ASSERT_H__

#include "../../../../../../../../../Android/Sdk/ndk/25.1.8937393/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/include/c++/v1/memory"
#include "../../../../../../../../../Android/Sdk/ndk/25.1.8937393/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/include/android/asset_manager.h"
#include "../../../../../../../../../Android/Sdk/ndk/25.1.8937393/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/include/GLES3/gl3.h"
#include "../../../../../../../../../Android/Sdk/ndk/25.1.8937393/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/include/c++/v1/string"
#include "../../../../../../../../../Android/Sdk/ndk/25.1.8937393/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/include/c++/v1/vector"

class TextureAsset {
public:
  typedef std::shared_ptr<TextureAsset> ptr;

  /*!
   * Loads a texture asset from the assets/ directory
   * @param assetManager Asset manager to use
   * @param assetPath The path to the asset
   * @return a shared pointer to a texture asset, resources will be reclaimed when it's cleaned up
   */
  static TextureAsset::ptr
  loadAsset(AAssetManager *assetManager, const std::string &assetPath);

  ~TextureAsset();

  /*!
   * @return the texture id for use with OpenGL
   */
  constexpr GLuint getTextureID() const { return m_textureID; }

private:
  inline TextureAsset(GLuint textureId) : m_textureID(textureId) {}

  GLuint m_textureID;
};

#endif