#ifndef GAME_H__
#define GAME_H__

#include <GLES3/gl3.h>

enum class GameState {
  MENU,
  ACTIVE,
  WIN,
};

class Game {
public:
  // constructor
  Game(GLuint width, GLuint height);

  // destructor
  ~Game();

  // game logic:

  // game initialization
  bool Init();

  // do collision checks
  void DoCollision();

  // process input from device
  void ProcessInput(float dt);

  // game logic calculation updates
  void Update(float dt);

  // game rendering
  void Render();

public:
  GameState State;
  GLuint Width, Height;
};


#endif
